/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
// will go into the header file
class Device
{
public:
    void setDeviceDetails(int,int);
    void printDeviceDetails();
    Device(int, int);
    Device();
    void operator+(int);
    bool operator==(Device device);
    
    
   private:
      int deviceId;
      int status;
    
};


bool Device::operator==(Device device){
    
        
        std::cout <<"operator overloading == at work";
        return deviceId == device.deviceId;
    
}





void Device::operator+(int whocares){
    
    std::cout<<"plus function at work" << whocares;
}

Device::Device(int deviceId, int status)
{
        this->deviceId =deviceId;
        this->status=status;
    
}

Device::Device(){}


//this will go in header definition

//implementation will start
void Device::setDeviceDetails(int deviceId,int tstatus){
    
    std::cout << "inside the function setDeviceDetails";
    this->deviceId = deviceId;
    status = tstatus;
    
}

void Device::printDeviceDetails()
{
    std::cout << deviceId <<  "" << status;    

}



void operator+(int nobodycares,Device d)
{
    std::cout <<"first argument is number";
    
}




bool operator==(Device device,Device device1){
    
        
        std::cout <<"operator overloading == at work";
        return deviceId == device.deviceId;
    
}


//end of mplemention

int main()
{
    
    Device device;
    Device device1(2,3);
    
    if( device == true)
            std::cout<< "devices are equal";
    else
            std::cout<<"devices are not equal";
    //device1+56; // you have to decide what you want this to do.
    // ok if i do this then my status should be added with 2.
    56+device1;//this may not be needed
    device.setDeviceDetails(23,4);
    device1.setDeviceDetails(44,5);
    device.printDeviceDetails();
    
    return 0;
}

